package com.xtinacodes.babynames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabynamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
