package com.xtinacodes.babynames.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import java.util.*;
import com.xtinacodes.babynames.models.Name;
import com.xtinacodes.babynames.repositories.*;

@Service
public class NameServ {
    
    @Autowired
    private NameRepo repo;

    // SELECT ALL
    public List<Name> selectAll(){
        return repo.findAll();
    }
    // SELECT ONE
    public Name selectOne(int e){
        return repo.findById(e).orElse(null);
    }
    // EDIT CREATE
    public Name save(Name e){
        return repo.save(e);
    }
    // DELETE
    public void delete(int e){
        repo.deleteById(e);
    }

}
