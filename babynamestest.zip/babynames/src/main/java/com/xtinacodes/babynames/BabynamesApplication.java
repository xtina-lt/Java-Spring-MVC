package com.xtinacodes.babynames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BabynamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BabynamesApplication.class, args);
	}

}
